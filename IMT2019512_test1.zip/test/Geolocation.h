#ifndef GEOLOCATION_H
#define GEOLOCATION_H

#include<stdlib.h>
#include<stdio.h>
#include<iostream>

#include "Ecosystem.h"

using namespace std;

class Geolocation : public Ecosystem
{
	private : 
		int latitude ; 
		int longitude ; 

	public :

		Geolocation(int longit , int lat) ;  

		// Geolocation(const Geolocation &data1) ;
		
		int get_longitude() ;
		
		int get_latitude() ; 
		
		void set_longitude(int longitude) ; 
		
		void set_latitude(int latitude) ; 
		
		// Geolocation :: ~Geolocation() ;


} ; 
#endif 