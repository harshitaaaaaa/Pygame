#ifndef ECOSYSTEM_H
#define ECOSYSTEM_H

#include<stdlib.h>
#include<stdio.h>
#include<iostream>

#include "Geolocation.h"

using namespace std;

class Ecosystem
{
	private :
		int no_of_orangutans ; 
		int no_of_pandas ; 
		int no_of_rhinoceros ; 
		int no_of_tigers ;
		bool is_alive ; 
		Geolocation loc ; 

	public :

	Ecosystem(Geolocation loc) ;
	
	// Ecosystem(const Ecosystem &data1) ;
	
	int get_no_of_pandas() ;
	
	int get_no_of_orangutans() ;

	int get_no_of_rhinoceros() ;

	int get_alive_now() ; 
	
	int get_no_of_tigers() ;

	int get_longitute() ;
	 
	int get_latitute() ;

	void set_no_of_pandas(int pandas) ;
	
	void set_no_of_orangutans(int orangutans) ;
	
	void set_no_of_rhinoceros(int rhinoceros) ;
	
	void set_no_of_tigers(int tigers) ;
	
	void add_pandas(int pandas) ;
	
	void add_orangutan(int orangutans) ;
	
	void add_rhinoceros(int rhinoceros) ;
	
	void add_tigers(int tigers) ;
	
	void delete_pandas(int pandas) ;
	
	void delete_orangutans(int orangutans) ;
	
	void delete_rhinoceros(int rhinoceros) ;
	
	void delete_tigers(int tigers) ;
	
	void delete_ecosystem() ;
	
	void copy_ecosystem(Geolocation loc , Ecosystem & new_eco , Ecosystem & copy_eco) ;

	friend ostream &operator <<(ostream &out , vector <Ecosystem> &eco)  ; 

	// ~Ecosystem() ;

} ;
#endif