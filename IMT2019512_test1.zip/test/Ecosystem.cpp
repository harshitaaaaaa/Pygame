#include<stdlib.h>
#include<iostream>
#include<math.h> 
using namespace std;

#include "Ecosystem.h"
#include "Geolocation.h"


// ################### CONSTRUCTOR ######################

Ecosystem :: Ecosystem(Geolocation loc) 
{
	this->loc = loc ; 
	this->no_of_pandas = 0 ; 
	this->no_of_rhinoceros = 0 ; 
	this->no_of_orangutans = 0 ; 
	this->no_of_tigers = 0 ; 
	this->is_alive = true ; 
}

// ################### COPY CONSTRUCTOR #########################

// Ecosystem :: Ecosystem(const Ecosystem &data1)
// {
// 	this->loc = data1.loc 
// } 



// ################## GETTERS #####################


int Ecosystem :: get_no_of_pandas()
{
	return this->no_of_pandas ; 
}

int Ecosystem :: get_no_of_orangutans()
{
	return this->no_of_orangutans ; 
}

int Ecosystem :: get_no_of_rhinoceros()
{
	return this->no_of_rhinoceros ; 
}

int Ecosystem :: get_no_of_tigers()
{
	return this->no_of_tigers ; 
}

int Ecosystem :: get_longitute()
{
	this->loc.get_longitute() ; 
}

int Ecosystem :: get_latitute()
{
	this->loc.get_latitute() ; 
}

int Ecosystem :: get_alive_now()
{
	if(this->get_alive  == true) 
	{
		return 1 ; 
	} 

	return 0 ; 
}


// ###################### SETTERS ######################


void Ecosystem :: set_no_of_pandas(int pandas)
{
	this->no_of_pandas = pandas ; 
}

void Ecosystem :: set_no_of_orangutans(int orangutans)
{
	this->no_of_orangutans = orangutans ; 
}

void Ecosystem :: set_no_of_rhinoceros(int rhinoceros)
{
	this->no_of_rhinoceros = rhinoceros ; 
} 

void Ecosystem :: set_no_of_tigers(int tigers)
{
	this->no_of_tigers = tigers ; 
}


// ######################### PANDAS ############################


void Ecosystem :: add_pandas(int pandas)
{
	this->no_of_pandas += pandas ; 
	this->set_no_of_pandas(this->no_of_pandas) ; 
}

void Ecosystem :: add_orangutan(int orangutans)
{
	this->no_of_orangutans += orangutans ; 
	this->set_no_of_orangutans(this->no_of_orangutans) ; 
}

void Ecosystem :: add_rhinoceros(int rhinoceros)
{
	this->no_of_rhinoceros += rhinoceros ; 
	this->set_no_of_rhinoceros(this->no_of_rhinoceros) ; 
} 

void Ecosystem :: add_tigers(int tigers)
{
	this->no_of_tigers  += tigers ; 
	this->set_no_of_tigers(this->no_of_tigers) ; 	
} 


// ######################### DELETE ###################################


void Ecosystem :: delete_pandas(int pandas)
{
	if(this->get_no_of_pandas() > pandas)
	{
		this->no_of_pandas -= pandas ; 
		this->set_no_of_pandas(this->no_of_pandas) ; 
	}
}

void Ecosystem :: delete_orangutans(int orangutans)
{
	if(this->get_no_of_orangutans() > orangutans)
	{
		this->no_of_orangutans -= orangutans ; 
		this->set_no_of_orangutans(this->no_of_orangutans) ; 
	}

}

void Ecosystem :: delete_rhinoceros(int rhinoceros)
{
	if(this->get_no_of_rhinoceros() > rhinoceros)
	{
		this->no_of_rhinoceros -= rhinoceros ; 
		this->set_no_of_rhinoceros(this->no_of_rhinoceros) ; 
	}
} 

void Ecosystem :: delete_tigers(int tigers)
{
	if(this->get_no_of_tigers() > tigers)
	{
		this->no_of_tigers  -= tigers ; 
		this->set_no_of_tigers(this->no_of_tigers) ; 	
	}
} 


// ###################### DELETE ECOSYSTEM ###########################

void Ecosystem :: delete_ecosystem()
{
	this->is_alive = false ; 
	this->set_no_of_pandas(0) ;
	this->set_no_of_orangutans(0) ;
	this->set_no_of_rhinoceros(0) ;
	this->set_no_of_tigers(0) ; 
}

// ######################## COPY ECOSYSTEM ##############################

void Ecosystem :: copy_ecosystem(Ecosystem & new_eco , Ecosystem & copy_eco)
{
	new_eco.set_no_of_pandas(copy_eco.get_no_of_pandas()) ; 
	new_eco.set_no_of_rhinoceros(copy_eco.get_no_of_rhinoceros()) ; 
	new_eco.set_no_of_orangutans(copy_eco.get_no_of_orangutans()) ; 
	new_eco.set_no_of_tigers(copy_eco.get_no_of_tigers()) ; 
}


// ########################## DESTRUCTOR ###################################

// Ecosystem:: ~Ecosystem()
// {
// 	delete no_of_orangutans ; 
// 	delete no_of_pandas ; 
// 	delete no_of_rhinoceros ; 
// 	delete no_of_tigers ; 
// 	delete loc ;  
// } 


// ################### OPERATOR OVERLOADING ##################################

ostream &operator <<(ostream &out , vector <Ecosystem> &eco) 
{
	for(int i=0 ; i<eco.size() ; i++)
	{	
		out << i << "," << eco[i].get_latitute() << "," << eco[i].get_longitute() << "," << eco[i].get_alive_now() << "," << eco[i].get_no_of_orangutans() << "," << eco[i].get_no_of_pandas() << "," << eco[i].get_no_of_rhinoceros() << "," << eco[i].get_no_of_tigers() << " " ; 
	}

	int total_rhinoceros ;
	int total_pandas ;
	int total_orangutans ;
	int total_tigers ;

	for(int i=0 ; i<eco.size() ; i++)
	{
		total_rhinoceros += eco[i].get_no_of_rhinoceros() ;
		total_pandas += eco[i].get_no_of_pandas() ;
		total_orangutans += eco[i].get_no_of_orangutans() ;
		total_tigers += eco[i].get_no_of_tigers() ; 
	}

	out << total_orangutans << "," << total_pandas << "," << total_rhinoceros << "," << total_tigers << endl ; 
}