#include<stdlib.h>
#include<iostream>
#include<math.h> 
using namespace std;

#include "Ecosystem.h"
#include "Geolocation.h"

// ###################### CONSTRUCTOR #############################

Geolocation :: Geolocation(int longit , int lat) 
{
	this->longitude = longit ; 
	this->latitude = lat ;
}

// ##################### COPY CONSTRUCTOR #########################

// Geolocation :: Geolocation(const Geolocation &data1)
// {
// 	this->longitude = data1.longitude; 
// 	this->latitude = data1.latitude ; 
// } 


 // ##################### GETTER #################################

int Geolocation :: get_longitude()
{
	return this->longitude ; 
}

int Geolocation :: get_latitude()
{
	return this->latitude ; 
}


// ####################### SETTERS ###############################

void Geolocation :: set_longitude(int longitude) 
{
	this->longitude = longitude ; 
}

void Geolocation :: set_latitude(int latitude) 
{
	this->latitude = latitude ; 
}

// ########################## DESTRUCTOR ##########################

// Geolocation :: ~Geolocation()
// {
// 	delete longitude ; 
// 	delete latitude ;  
// } 






