#include<iostream>
#include<string.h>
#include<sstream>
#include<vector>
#include<math.h>

#include "Ecosystem.h"
#include "Geolocation.h"

using namespace std; 

int main() 
{
	string str ; 

	getline(cin , str) ; 

	char char_array[str.length()] ;

	// cout << str.length() << endl ; 

	strcpy(char_array , str.c_str()) ; 

	vector <Ecosystem> eco ;

	int i=0 ; 

	while(i < str.length()) 
	{
		if(char_array[i] == 'A')
		{
			i = i+2 ; 

			string s = "" ; 


			while(!(char_array[i] == ','))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}
			int latitude = stoi(s)

			i++ ; 

			s = "" ; 

			while(!(char_array[i] == ' '))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int longitude = stoi(s) ;
			i++ ;  

			Geolocation loc(longitude , latitude) ; 

			eco.push_back(loc) ; 

		}

		else if(char_array[i] == 'A' && char_array[i+1] == 'A')
		{
			i = i+3 ; 

			char animal = char_array[i] ; 
			i = i+2 ; 

			string s = "" ; 

			while(!(char_array[i] == ','))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int no_of_animals = stoi(s) ; 

			i++ ; 

			s = "" ; 

			while(!(char_array[i] == ' '))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int index = stoi(s) ; 
			i++ ; 

			if(animal == 'O')
			{
				eco[index].add_orangutans(no_of_animals) ; 
			}

			if(animal == 'P')
			{
				eco[index].add_pandas(no_of_animals) ; 	
			}

			if(animal == 'R')
			{
				eco[index].add_rhinoceros(no_of_animals) ; 
			}

			if(animal == 'T')
			{
				eco[index].add_tigers(no_of_animals) ; 
			}


		}

		else if(char_array[i] == 'D' && char_array[i+1] == 'D')
		{
			i = i+3 ; 

			char animal = char_array[i] ; 
			i = i+2 ; 

			string s = "" ; 

			while(!(char_array[i] == ','))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int no_of_animals = stoi(s) ; 

			i++ ; 

			s = "" ; 

			while(!(char_array[i] == ' '))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int index = stoi(s) ; 
			i++ ; 

			if(animal == 'O')
			{
				eco[index].delete_orangutans(no_of_animals) ; 
			}

			if(animal == 'P')
			{
				eco[index].delete_pandas(no_of_animals) ; 	
			}

			if(animal == 'R')
			{
				eco[index].delete_rhinoceros(no_of_animals) ; 
			}

			if(animal == 'T')
			{
				eco[index].delete_tigers(no_of_animals) ; 
			}

		}

		else if(char_array[i] == 'D')
		{
			i = i+2 ; 

			string s = "" ; 
			while(!(char_array[i] == ' '))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int index = stoi(s) ; 
			i++ ; 

			eco[index].delete_ecosystem() ; 
		}

		else if(char_array[i] == 'C')
		{
			i = i+2 ; 

			string s = "" ; 
			while(!(char_array[i] == ','))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int index = stoi(s) ;

			i++ ; 

			s = "" ;

			while(!(char_array[i] == ','))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int latitude = stoi(s) ; 

			i++ ; 

			s = "" ; 

			while(!(char_array[i] == ' '))
			{
				s = s + char_array[i] ; 
				i++ ; 
			}

			int longitude = stoi(s) ; 

			i++ ; 

			Ecosystem new_eco(longitude , latitude) ; 
			new_eco.copy_ecosystem(new_eco , eco[index]) ; 
			eco.push_back(new_eco) ; 

		}

		else 
		{
			cout << "-1" << endl ; 
			return 0 ; 
		}
		
	}


	cout << eco ; 
	
}